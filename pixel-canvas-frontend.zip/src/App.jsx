import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Welcome to Pixel Canvas!</h1>
      <p>This is where users can paint pixels and buy squares!</p>
    </div>
  );
};

export default App;